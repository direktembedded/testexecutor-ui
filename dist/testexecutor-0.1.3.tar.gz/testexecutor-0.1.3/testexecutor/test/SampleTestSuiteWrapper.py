"""
Copyright (c) 2020 Direkt, Australia
Licensed under BSD-3-Clause, refer LICENSE
"""
from testexecutor.model.TestSuiteModel import TestSuiteModel
from testexecutor.model.ResultModel import ResultModel
from testexecutor.control.TestSuiteListener import TestSuiteListener
from testexecutor.test.SampleIdentificationData import SampleIdentificationData
from testexecutor.test.SampleTestExecution import SampleTestExecution


class SampleTestSuiteWrapper(TestSuiteModel, TestSuiteListener):
    """
    Class to demonstrate interfacing between TestSuiteWidget GUI and TestSuiteModel and Test Runs which exercise
    the TestListenerApi methods.
    TestSuiteModel functionality, like the callback function for the identification widget, are linked via the
    TestSuiteModel constructor, and suite control business logic written in them.
    The TestListenerApi methods are implement and exercise the TestSuitModel properties directly.
    """
    def __init__(self, title="Sample Suite"):
        self._id_data = SampleIdentificationData()
        self._id_data.populate()
        self._results = ResultModel()
        self._testrun = None
        TestSuiteModel.__init__(self, self._id_data, self._results, self._input_filter,
                                setstate_callback=self._state_control_callback, title=title)
        self.suitestate = TestSuiteModel.STATE_IDLE
        TestSuiteListener.__init__(self, model=self)

    def _start_suite(self, response=None):
        """
        This internal _start_suite will start the new thread which will be the test run execution. The test run in turn
        should call the TestListenerApi's suiteStart
        :return:
        """
        self.instructions.clear()
        if not self._testrun:
            self.suitestate = TestSuiteModel.STATE_STARTING  # recursive loop risk!
            self._testrun = SampleTestExecution(listener=self, exit_callback=self._on_exit)
            self._testrun.run()

    def _stop_suite(self):
        self._testrun.stop()

    def _clear_suite(self):
        self.clear()

    def _state_control_callback(self, st):
        newstate = None
        runningStates = [TestSuiteModel.STATE_RUNNING, TestSuiteModel.STATE_STARTING]
        if st == TestSuiteModel.STATE_STOPPING:
            if self.suitestate in runningStates:
                newstate = st
                self._stop_suite()
        else:
            newstate = st
        return newstate

    def _input_filter(self, input):
        """
        For demonstration on the very first input entry, we make the suite state 'ready'
        :param input: The new input text from UI
        :return: None
        """
        self._id_data.input_filter(input)
        if self._id_data.hasModel():
            msg = "Setup your device under test\nThen press Start"
            self.asyncInstructions(self._id_data.getValue(SampleIdentificationData.Model), msg, callback=self._start_suite, control=["Start"])
            self.suitestate = TestSuiteModel.STATE_READY

    def _on_exit(self):
        if self.suitestate == TestSuiteModel.STATE_STOPPING:
            self.suitestate = TestSuiteModel.STATE_STOPPED
        self._testrun = None
